from django.urls import path
from . import views

urlpatterns = [
    path('music/', views.music_list),   # 모든 음악 정보 조회
]
